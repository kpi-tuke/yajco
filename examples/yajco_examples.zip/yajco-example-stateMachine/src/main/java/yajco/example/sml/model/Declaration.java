package yajco.example.sml.model;

public abstract class Declaration {
}
