package yajco.example.imperative.machine;

public class MachineException extends RuntimeException {

    public MachineException() {
    }

    public MachineException(String msg) {
        super(msg);
    }
}
