package yajco.example.imperative.model.statement;

public interface Statement {
    void execute();
}
