package yajco.robot.karel.runtime;

public class ExecutionException extends RuntimeException {
    public ExecutionException(String msg) {
        super(msg);
    }
}
