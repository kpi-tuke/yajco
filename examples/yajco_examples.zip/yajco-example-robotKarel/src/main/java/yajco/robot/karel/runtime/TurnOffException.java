package yajco.robot.karel.runtime;

public class TurnOffException extends RuntimeException {
    public TurnOffException() {
    }
}
