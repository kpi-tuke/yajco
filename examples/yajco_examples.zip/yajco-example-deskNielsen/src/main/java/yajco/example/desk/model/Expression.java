package yajco.example.desk.model;

import yajco.annotation.Parentheses;

@Parentheses
public abstract class Expression {

    public abstract String code();

}
