package yajco.robot.model;

/**
 *
 * @author DeeL
 */
public interface Command {

    public void execute();
    
}
