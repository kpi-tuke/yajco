/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package yajco.example.json.model;



/**
 *
 * @author Šimonko
 */
public class JsonFile {

    private Object obj;


    public JsonFile(Object obj) {

        this.obj = obj;

    }

}
